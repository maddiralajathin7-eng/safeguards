const sosBtn = document.getElementById("sosBtn");
const alertCard = document.getElementById("alertCard");
const resultCard = document.getElementById("resultCard");
const countdownEl = document.getElementById("countdown");
const cancelBtn = document.getElementById("cancelBtn");
const resetBtn = document.getElementById("resetBtn");
const statusEl = document.getElementById("status");
const locationText = document.getElementById("locationText");
const mapLink = document.getElementById("mapLink");
const messageBox = document.getElementById("messageBox");

let timer = null;
let cancelled = false;

sosBtn.addEventListener("click", startSOS);
cancelBtn.addEventListener("click", cancelSOS);
resetBtn.addEventListener("click", resetDemo);

function startSOS() {
  cancelled = false;
  sosBtn.disabled = true;
  alertCard.classList.remove("hidden");
  resultCard.classList.add("hidden");
  statusEl.textContent = "Emergency countdown started";
  let n = 5;
  countdownEl.textContent = n;

  timer = setInterval(() => {
    n--;
    countdownEl.textContent = n;
    if (n <= 0) {
      clearInterval(timer);
      if (!cancelled) activateSOS();
    }
  }, 1000);
}

function cancelSOS() {
  cancelled = true;
  clearInterval(timer);
  alertCard.classList.add("hidden");
  sosBtn.disabled = false;
  statusEl.textContent = "SOS cancelled — system ready";
}

function activateSOS() {
  alertCard.classList.add("hidden");
  resultCard.classList.remove("hidden");
  statusEl.textContent = "SOS activated";

  if (!navigator.geolocation) {
    showLocation("Location not supported by this browser.");
    return;
  }

  locationText.textContent = "Requesting location...";
  navigator.geolocation.getCurrentPosition(
    pos => {
      const lat = pos.coords.latitude.toFixed(6);
      const lon = pos.coords.longitude.toFixed(6);
      showLocation(`${lat}, ${lon}`, lat, lon);
    },
    () => {
      showLocation("Location permission denied or unavailable.");
    },
    { enableHighAccuracy: true, timeout: 10000 }
  );
}

function showLocation(text, lat, lon) {
  locationText.textContent = text;
  if (lat && lon) {
    const url = `https://www.google.com/maps?q=${lat},${lon}`;
    mapLink.href = url;
    mapLink.style.display = "inline-block";
    messageBox.innerHTML =
      `<strong>Demo emergency message:</strong><br>
       SOS activated. Please check on the user immediately.<br>
       Location: ${lat}, ${lon}`;
  } else {
    mapLink.style.display = "none";
    messageBox.innerHTML =
      `<strong>Demo emergency message:</strong><br>
       SOS activated. Location could not be obtained in this demo.`;
  }
}

function resetDemo() {
  clearInterval(timer);
  cancelled = false;
  alertCard.classList.add("hidden");
  resultCard.classList.add("hidden");
  sosBtn.disabled = false;
  statusEl.textContent = "System ready";
  locationText.textContent = "Requesting...";
  mapLink.removeAttribute("href");
  mapLink.style.display = "inline-block";
  messageBox.textContent = "";
}
