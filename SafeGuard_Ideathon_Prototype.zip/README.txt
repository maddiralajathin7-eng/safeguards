# SafeGuard Ideathon Prototype

A Chromebook-only web prototype for an emergency safety concept.

## Run
1. Open `index.html` in a browser.
2. Click the red SOS button.
3. Let the 5-second countdown finish.
4. Allow location access when the browser asks.
5. Click "Open Location" to view the map.

## Important
This is a demonstration prototype. It does NOT send real SMS/calls or contact emergency services.

For a production system, use an appropriate verified emergency communication provider and follow local laws and privacy requirements.
